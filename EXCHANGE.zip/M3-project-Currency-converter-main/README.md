# M3-project - Currency Converter
### This is an application for bank sites for currency conversion.
#### The converter has four currencies for exchange, but if necessary, it is possible to add other currencies
#### HTML/CSS/JavaScript
